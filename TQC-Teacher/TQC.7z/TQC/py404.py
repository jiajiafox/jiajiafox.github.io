n=input()
print(n[::-1])