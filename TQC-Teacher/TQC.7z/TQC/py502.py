def compute(x,y):
    return x*y

x=eval(input())
y=eval(input())
print(compute(x,y))